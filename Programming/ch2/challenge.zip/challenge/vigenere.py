def decode_vigenere(encoded_text, key):
    result = ""
    key_length = len(key)
    key_as_int = [ord(i) - ord('a') for i in key.lower()]
    for i in range(len(encoded_text)):
        if encoded_text[i].isalpha():
            offset = ord('a') if encoded_text[i].islower() else ord('A')
            value = (ord(encoded_text[i]) - offset - key_as_int[i % key_length]) % 26
            result += chr(value + offset)
        else:
            result += encoded_text[i]
    return result





decoded_message = decode_vigenere(plaintext, remote_key)
print(f"Decoded Message: {decoded_message}")



#p = "??????????????????????????????"
#r_k = "UPPERCASE ONLY"  #FCCID 
