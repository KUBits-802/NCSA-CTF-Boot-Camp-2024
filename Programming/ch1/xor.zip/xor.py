#!/usr/bin/env python3

def xor_cipher(data, key):
    encrypted_data = []
    key_length = len(key)

    # XOR each character of the data with the corresponding key byte
    for i in range(len(data)):
        encrypted_char = chr(ord(data[i]) ^ key[i % key_length])  # Use key as byte array
        encrypted_data.append(encrypted_char)

    # Join the encrypted characters into a final string
    encrypted_text = ''.join(encrypted_data)

    return encrypted_text


# Key in hexadecimal format
key_hex = ""
key = bytes.fromhex(key_hex)  # Convert hex key to byte array

# Plaintext message
# p = "xxxxxxxxxxxxx3942.043lb77g6c3g3m4bdll64em`aagee3ge(xxxxxxxxxxxxxxxx"
# k = Range of 1000 to 9999

# Decrypt using XOR cipher
decrypted_text = xor_cipher(plaintext, key)
print("Decrypted text:", decrypted_text)
